﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class Tracking : MonoBehaviour
//{
//    GameObject player;
//    public float range = 20;
//    bool isPlayerClose = false;
//    // Start is called before the first frame update
//    void Start()
//    {
        
//    }

//    // Update is called once per frame
//    void Update()
//    {
//        //if (Vector3.Distance(transform.position, player) < range)
//        {

//        }
//    }
//}
